# Ethorse Core

## How to use

Link to DAPP: [Ethorse](https://ethorse.github.io/Betting/) 
 
Bet on a cryptocurrency and win against other bettors with Ethorse Smart Contract

- Simply choose a winner among BTC, ETH and LTC for a fixed 24 hour period -09:00 Nov 5 to 09:00 Nov 6, 2017 UTC.
- "Place bet" after entering an amount you are willing to bet (0.1 - 1 Ropsten ETH) from a browser with Metamask extension, or Mist.
- Parimutuel Betting: Winner takes all (Fee 1%)
- Price pulled from Coinmarketcap.com API through Oraclize.it at the beginning and end of the bet period
- After bet closes, click “Check result” to see your winnings and “Claim” to submit a 0 ETH transaction that in turn sends your winnings.

Bet on a favorite to easily win a small payout because it only needs to beat lesser opponents. 
Alternatively, bet on an underdog and win a huge payout. Tip: Use the Odds. Questions and feedback are welcome.

Reddit Link: [/r/Ethorse](https://www.reddit.com/r/Ethorse/)
